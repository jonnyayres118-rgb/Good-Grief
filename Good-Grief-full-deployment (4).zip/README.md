# Good Grief

A complete responsive prototype for planning, updating and privately sharing funeral wishes.

## Included

- Campaign landing page and pricing
- Account creation and returning-user sign-in
- Server-created Stripe Checkout for £29/year and £75 lifetime memberships
- Ten-part funeral planner with progress and autosave
- Paid-only invitations, account-protected read-only plan access and revocation
- 50% first-year Annual referral discount for invited viewers
- A clear access register for outgoing and incoming plan access
- Supabase client integration and row-level-security schema
- Protected HubSpot lead-capture endpoint integration
- Responsive desktop, tablet and mobile layouts
- Vercel and Sites deployment configuration

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

The standard production frontend is written to `dist/client`. Vercel also deploys the functions in `api/` for checkout, webhooks and protected sharing.

## Production services

Copy `.env.example` to `.env.local` and add Supabase, Stripe and the protected HubSpot lead-capture endpoint. See `INTEGRATIONS.md` and `supabase-schema.sql`.
