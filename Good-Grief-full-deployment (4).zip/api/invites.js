import { authenticate, bodyOf, getAdmin, hashInviteToken, isPaidProfile, makeInviteToken, requestOrigin, send } from "../server/services.js";

async function accessSummary(admin, user) {
  const [{ data: outgoing, error: outgoingError }, { data: incoming, error: incomingError }] = await Promise.all([
    admin.from("plan_access").select("id,invited_email,status,created_at,accepted_at").eq("owner_user_id", user.id).neq("status", "revoked").order("created_at", { ascending: false }),
    admin.from("plan_access").select("id,owner_user_id,status,accepted_at").eq("viewer_user_id", user.id).eq("status", "accepted").order("accepted_at", { ascending: false }),
  ]);
  if (outgoingError) throw outgoingError;
  if (incomingError) throw incomingError;
  const ownerIds = [...new Set((incoming || []).map(item => item.owner_user_id))];
  const { data: owners } = ownerIds.length
    ? await admin.from("profiles").select("user_id,full_name,email").in("user_id", ownerIds)
    : { data: [] };
  const ownerMap = Object.fromEntries((owners || []).map(owner => [owner.user_id, owner]));
  return {
    peopleWithAccess: outgoing || [],
    plansSharedWithMe: (incoming || []).map(item => ({ ...item, owner: ownerMap[item.owner_user_id] || null })),
  };
}

export default async function handler(req, res) {
  try {
    const user = await authenticate(req);
    if (!user) return send(res, 401, { error: "Please sign in." });
    const admin = getAdmin();

    if (req.method === "GET") return send(res, 200, await accessSummary(admin, user));

    if (req.method === "DELETE") {
      const { id } = bodyOf(req);
      const { error } = await admin.from("plan_access").update({ status: "revoked", revoked_at: new Date().toISOString() }).eq("id", id).eq("owner_user_id", user.id);
      if (error) throw error;
      return send(res, 200, await accessSummary(admin, user));
    }

    if (req.method !== "POST") return send(res, 405, { error: "Method not allowed" });
    const { data: profile } = await admin.from("profiles").select("payment_status").eq("user_id", user.id).maybeSingle();
    if (!isPaidProfile(profile)) return send(res, 402, { error: "Complete payment before sharing your plan." });

    const { email } = bodyOf(req);
    const invitedEmail = String(email || "").trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(invitedEmail)) return send(res, 400, { error: "Enter a valid email address." });
    if (invitedEmail === String(user.email || "").toLowerCase()) return send(res, 400, { error: "Invite someone other than yourself." });
    const { data: existing } = await admin.from("plan_access").select("id,status").eq("owner_user_id", user.id).eq("invited_email", invitedEmail).maybeSingle();
    if (existing?.status === "accepted") return send(res, 409, { error: "This person already has access." });

    const token = makeInviteToken();
    const record = {
      owner_user_id: user.id,
      invited_email: invitedEmail,
      token_hash: hashInviteToken(token),
      status: "pending",
      viewer_user_id: null,
      accepted_at: null,
      revoked_at: null,
    };
    const query = existing
      ? admin.from("plan_access").update(record).eq("id", existing.id).select("id,status,invited_email,created_at").single()
      : admin.from("plan_access").insert(record).select("id,status,invited_email,created_at").single();
    const { data: invite, error } = await query;
    if (error) throw error;
    return send(res, 200, { invite, inviteUrl: `${requestOrigin(req)}/shared/${token}` });
  } catch (error) {
    console.error("invites", error);
    return send(res, 500, { error: error.message || "Unable to manage access." });
  }
}
